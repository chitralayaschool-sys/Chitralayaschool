// interactions
document.getElementById('year').textContent = new Date().getFullYear();

const slider = document.querySelector('.testimonial-slider');
if(slider){
  let pos = 0;
  setInterval(()=>{
    pos = (pos + 320) % (slider.scrollWidth || 960);
    slider.scrollTo({left: pos, behavior:'smooth'});
  }, 3500);
}