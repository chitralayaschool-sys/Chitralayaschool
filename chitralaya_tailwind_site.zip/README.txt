Chitralaya School of Arts - Tailwind Multi-page Site
Files:
- index.html, about.html, courses.html, gallery.html, contact.html
- assets/ (contains uploaded images: logo, classroom photo, founder photo as founder.jpg)

Deploy:
- Zip this folder and drag & drop to Netlify (Sites -> Add new site).
- After deploy, go to Site settings -> Forms to view submissions. Enable notifications to receive emails at chitralayaschool@gmail.com.

Notes:
- Replace gallery placeholder images with your real photos in assets/.
- If you want menu icons / fonts changed, tell me and I'll update.
